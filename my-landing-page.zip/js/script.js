const sections = document.querySelectorAll('section');
window.addEventListener('scroll', () => {
    let triggerBottom = window.innerHeight / 1.1;
    sections.forEach(section => {
        const top = section.getBoundingClientRect().top;
        if(top < triggerBottom) section.classList.add('visible');
    });
});